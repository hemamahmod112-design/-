import type { CookieOptions, Request } from "express";

const LOCAL_HOSTS = new Set(["localhost", "127.0.0.1", "::1"]);

function isIpAddress(host: string) {
  // Basic IPv4 check and IPv6 presence detection.
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host)) return true;
  return host.includes(":");
}

function isSecureRequest(req: Request) {
  if (req.protocol === "https") return true;

  const forwardedProto = req.headers["x-forwarded-proto"];
  if (!forwardedProto) return false;

  const protoList = Array.isArray(forwardedProto)
    ? forwardedProto
    : forwardedProto.split(",");

  return protoList.some(proto => proto.trim().toLowerCase() === "https");
}

export function getSessionCookieOptions(
  req: Request
): Pick<CookieOptions, "domain" | "httpOnly" | "path" | "sameSite" | "secure"> {
  // const hostname = req.hostname;
  // const shouldSetDomain =
  //   hostname &&
  //   !LOCAL_HOSTS.has(hostname) &&
  //   !isIpAddress(hostname) &&
  //   hostname !== "127.0.0.1" &&
  //   hostname !== "::1";

  // const domain =
  //   shouldSetDomain && !hostname.startsWith(".")
  //     ? `.${hostname}`
  //     : shouldSetDomain
  //       ? hostname
  //       : undefined;

  const secure = isSecureRequest(req);

  return {
    httpOnly: true,
    path: "/",
    // SameSite=None يتطلّب Secure=true إلزاميًا في المتصفحات الحديثة، وإلا
    // بيرفض المتصفح تخزين الكوكي تمامًا (يعني تسجيل الدخول بينجح في الشبكة
    // لكن الجلسة متتحفظش). التطبيق بيقدّم الـ API والواجهة من نفس الأصل
    // (same-origin)، فـ Lax آمن وكافٍ لما الاتصال مش HTTPS (تطوير محلي أو
    // نشر بدون TLS)، ونستخدم None بس لما الاتصال فعلاً Secure.
    sameSite: secure ? "none" : "lax",
    secure,
  };
}
