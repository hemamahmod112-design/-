import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import type { User } from "../drizzle/schema";
import { getSessionCookieOptions } from "./_core/cookies";
import { createSessionToken, hashPassword, isValidEmail, isValidPassword, verifyPassword } from "./_core/localAuth";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, publicProcedure, router } from "./_core/trpc";
import { createLocalUser, createProduct, deleteProduct, getSettings, getUserByEmail, listAllProducts, listOrders, listProducts, touchLastSignedIn, updateOrderStatus, updateProduct, updateSettings } from "./db";

// مهم أمنيًا: صف المستخدم في قاعدة البيانات فيه passwordHash (الهاش المشفّر
// بـ bcrypt). ctx.user وأي قيمة راجعة من db.ts بتحمل الصف كامل، لكن مفيش أي
// سبب يخلي الهاش ده يوصل للمتصفح أو يتخزن في كاش react-query على جهاز
// العميل. الدالة دي بتستبعد الحقل ده قبل ما أي استجابة تتبعت للفرونت.
function toPublicUser(user: User): Omit<User, "passwordHash"> {
  const { passwordHash: _passwordHash, ...publicUser } = user;
  return publicUser;
}

const authInput = z.object({
  email: z.string().min(3).max(320),
  password: z.string().min(1),
});

const registerInput = authInput.extend({
  name: z.string().min(2).max(120),
});

const productInput = z.object({
  name: z.string().min(2),
  description: z.string().optional(),
  category: z.string().min(2),
  priceMinor: z.number().int().positive(),
  compareAtMinor: z.number().int().positive().optional(),
  imageUrl: z.string().url().optional(),
  stock: z.number().int().min(0),
  status: z.enum(["active", "draft", "archived"]).default("active"),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => (opts.ctx.user ? toPublicUser(opts.ctx.user) : null)),
    register: publicProcedure.input(registerInput).mutation(async ({ input, ctx }) => {
      const email = input.email.trim().toLowerCase();
      if (!isValidEmail(email)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "بريد إلكتروني غير صالح" });
      }
      if (!isValidPassword(input.password)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "كلمة المرور لازم تكون 8 أحرف على الأقل" });
      }
      const existing = await getUserByEmail(email);
      if (existing) {
        throw new TRPCError({ code: "CONFLICT", message: "البريد الإلكتروني مسجل بالفعل" });
      }

      const passwordHash = await hashPassword(input.password);
      let user;
      try {
        user = await createLocalUser({ name: input.name.trim(), email, passwordHash });
      } catch (error) {
        // في حالة تسجيلين متزامنين لنفس البريد، فحص "existing" فوق ممكن
        // يعدي الاتنين قبل ما أي حد يتسجل، وقاعدة البيانات هي اللي هتمنع
        // التكرار فعليًا عبر قيد UNIQUE على email. هنا بنحوّل خطأ القاعدة
        // لرسالة واضحة بدل ما يظهر خطأ سيرفر عام (500) للمستخدم.
        const message = error instanceof Error ? error.message : String(error);
        if (/duplicate|unique/i.test(message)) {
          throw new TRPCError({ code: "CONFLICT", message: "البريد الإلكتروني مسجل بالفعل" });
        }
        throw error;
      }
      if (!user) {
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "تعذر إنشاء الحساب" });
      }

      const token = await createSessionToken(user.id);
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.cookie(COOKIE_NAME, token, { ...cookieOptions, maxAge: ONE_YEAR_MS });
      return { success: true, user: toPublicUser(user) } as const;
    }),
    login: publicProcedure.input(authInput).mutation(async ({ input, ctx }) => {
      const email = input.email.trim().toLowerCase();
      const user = await getUserByEmail(email);
      if (!user || !(await verifyPassword(input.password, user.passwordHash))) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "البريد الإلكتروني أو كلمة المرور غير صحيحة" });
      }

      await touchLastSignedIn(user.id);
      const token = await createSessionToken(user.id);
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.cookie(COOKIE_NAME, token, { ...cookieOptions, maxAge: ONE_YEAR_MS });
      return { success: true, user: toPublicUser(user) } as const;
    }),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  store: router({
    products: publicProcedure.input(z.object({ search: z.string().optional(), category: z.string().optional() }).optional()).query(({ input }) => listProducts(input?.search, input?.category)),
    settings: publicProcedure.query(() => getSettings()),
  }),
  admin: router({
    products: adminProcedure.query(() => listAllProducts()),
    createProduct: adminProcedure.input(productInput).mutation(({ input }) => createProduct(input)),
    updateProduct: adminProcedure.input(z.object({ id: z.number().int(), data: productInput.partial() })).mutation(({ input }) => updateProduct(input.id, input.data)),
    deleteProduct: adminProcedure.input(z.object({ id: z.number().int() })).mutation(({ input }) => deleteProduct(input.id)),
    orders: adminProcedure.query(() => listOrders()),
    updateOrderStatus: adminProcedure.input(z.object({ id: z.number().int(), status: z.enum(["new", "processing", "shipped", "completed", "cancelled"]) })).mutation(({ input }) => updateOrderStatus(input.id, input.status)),
    settings: adminProcedure.query(() => getSettings()),
    updateSettings: adminProcedure.input(z.record(z.string(), z.string())).mutation(({ input }) => updateSettings(input)),
  }),
});

export type AppRouter = typeof appRouter;
