import { useState } from "react";
import { Link, useLocation } from "wouter";
import { TRPCClientError } from "@trpc/client";
import { useAuth } from "@/_core/hooks/useAuth";

export default function Login() {
  const auth = useAuth();
  const [, navigate] = useLocation();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  if (auth.isAuthenticated) {
    navigate("/");
    return null;
  }

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      if (mode === "register") {
        await auth.register(name, email, password);
      } else {
        await auth.login(email, password);
      }
      navigate("/");
    } catch (err) {
      if (err instanceof TRPCClientError) {
        setError(err.message);
      } else {
        setError("حدث خطأ غير متوقع، حاول مرة أخرى");
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div dir="rtl" className="grid min-h-screen place-items-center bg-[#fbfaf8] px-4">
      <div className="w-full max-w-md rounded-3xl bg-white p-8 shadow-xl">
        <Link href="/" className="flex items-center gap-2 text-xl font-black text-[#39206f]">
          <span className="grid h-10 w-10 place-items-center rounded-2xl bg-[#f6c744]">✦</span> سوقنا
        </Link>

        <h1 className="mt-6 text-2xl font-black">
          {mode === "login" ? "تسجيل الدخول" : "إنشاء حساب جديد"}
        </h1>
        <p className="mt-2 text-sm text-[#756b62]">
          {mode === "login"
            ? "ادخل ببريدك الإلكتروني وكلمة المرور."
            : "أول حساب يتسجل في المنصة يترقّى تلقائياً إلى مدير."}
        </p>

        <form onSubmit={submit} className="mt-6 grid gap-4">
          {mode === "register" && (
            <input
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="الاسم"
              required
              className="rounded-xl border p-3"
            />
          )}
          <input
            type="email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            placeholder="البريد الإلكتروني"
            required
            className="rounded-xl border p-3"
          />
          <input
            type="password"
            value={password}
            onChange={e => setPassword(e.target.value)}
            placeholder="كلمة المرور"
            required
            minLength={8}
            className="rounded-xl border p-3"
          />

          {error && <div className="rounded-xl bg-[#fff0ec] p-3 text-sm text-[#ed6a4b]">{error}</div>}

          <button
            type="submit"
            disabled={submitting}
            className="mt-2 rounded-full bg-[#4d2c99] px-6 py-3 font-bold text-white disabled:opacity-60"
          >
            {submitting ? "جاري التنفيذ..." : mode === "login" ? "دخول" : "إنشاء الحساب"}
          </button>
        </form>

        <button
          onClick={() => { setMode(mode === "login" ? "register" : "login"); setError(null); }}
          className="mt-5 block w-full text-center text-sm font-bold text-[#7651c8]"
        >
          {mode === "login" ? "ليس لديك حساب؟ سجّل الآن" : "لديك حساب بالفعل؟ سجّل الدخول"}
        </button>

        <Link href="/" className="mt-4 block text-center text-sm text-[#8d8279]">
          العودة للمتجر
        </Link>
      </div>
    </div>
  );
}
